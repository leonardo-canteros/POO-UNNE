
/**
 * Esta clase llamada nuevaPersona ejecutara y creara una persona.
 * 
 * @author joaquin Ferretto 
 */
public class nuevaPersona
{
    public static void main()
    {
       Persona Persona2 = new Persona(35123456, 1996 , "juan", "perez");
       Persona2.mostrar();
    }


}
