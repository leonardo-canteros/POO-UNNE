
/**
 * Esta clase describe al objeto de clase laboratorio.
 * 
 * @author Joaquin Ferretto 
 *
 */
public class Laboratorio
{
    //Declaracion de atributos del objeto.
    private int compraMinima, diaEntrega;
    private String nombre,domicilio,telefono;

    /**
     * Constructor de objetos de clase laboratorio.
     * @param p_compraMinima, p_diaEntrega, p_nombre, p_domicilio, p_telefono.
     */
    Laboratorio(int p_compraMinima, int p_diaEntrega,String p_nombre, String p_domicilio, String p_telefono)
    {
                compraMinima = p_compraMinima;
                diaEntrega = p_diaEntrega;
                nombre = p_nombre;
                domicilio = p_domicilio;
                telefono = p_telefono;
    }
    /**
     * Constructor de objetos de clase laboratorio.
     * @param p_nombre, p_domicilio, p_telefono.
     */
    Laboratorio(String p_nombre,String p_domicilio, String p_telefono){
                nombre = p_nombre;
                domicilio = p_domicilio;
                telefono = p_telefono;
    }
    /**
     * Metodo que asienta la nueva compra minima.
     * @param p_compraMinima
     */
    public void nuevaCompraMinima(int p_compraMinima){
        compraMinima = p_compraMinima;
    }
    /**
     * Metodo que asienta el nuevo dia de entrega.
     * @param p_diaEntrega
     */
    public void nuevoDiaEntrega(int p_diaEntrega){
        diaEntrega = p_diaEntrega;
    }
    /**
     * Metodo que muestra el nomre del laboratorio, su domicilio y su telefono.
     * @param p_compraMinima, p_diaEntrega, p_nombre, p_domicilio, p_telefono.
     */
    public void mostrar(){
        System.out.println("laboratorio : " + nombre);
        System.out.println("domicilio: " + domicilio + " - " + "Telefono: " + telefono );
    }
    
    
    
    
    
    
    

}
