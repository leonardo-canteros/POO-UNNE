
public class EjucutadorCliente
{

    public static void main ()
    {
        Cliente mario = new Cliente (27478951,"Berardi","Mario", 4575.50);
        mario.mostrar();
        mario.nuevoSaldo(500);
        mario.agregarSaldo(500);
        mario.mostrar();
         mario.nuevoSaldo(-1000);
        mario.agregarSaldo(-1000);
        mario.mostrar();
    }
}
