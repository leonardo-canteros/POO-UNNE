
/**
 * Write a description of class empleadoNuevo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class empleadoNuevo
{
  
    public static void main()
    {
      empleado juan = new empleado(20437476026L,"juan cruz","galarza",1500.50,2014);
      juan.mostrar();
      System.out.println(juan.mostrarLinea());
    }
}
