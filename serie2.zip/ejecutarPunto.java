
/**
 * Write a description of class ejecutarPunto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ejecutarPunto
{
    public static void main(){
        punto bomba = new punto(0,0);
        bomba.desplazar(5,5);
        bomba.mostrar();
        punto bombaInglaterra = new punto(50, -377);
        bombaInglaterra.desplazar(230, -600);
        bombaInglaterra.mostrar();
    }
    
}
