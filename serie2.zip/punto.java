public class punto
{
    private double x;
    private double y;
    /**
     * Constructor for objects of class punto
     */
    public punto()
    {
        y = 0;
        x = 0;
    }
    
    public punto(double p_x, double p_y){
        this.setX(p_x);
        this.setY(p_y);
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    private void setX(double p_x)
    {
       this.x=p_x;
    }
    private void setY(double p_y)
    {
       this.y=p_y;
    }
    
    public double getX(){
        return this.x;
    }
    
       public double getY(){
        return this.y;
    }
    
    public void desplazar(double p_x, double p_y){
        x += p_x;
        y += p_y;
    }
    
    public String coordenadas(){
        return this.getX() + "," + this.getY();
    }
    
    public void mostrar(){
        System.out.println("Punto. x:" + this.getX() + "," + " " + "Y:" + this.getY());
    }
    
    
}
