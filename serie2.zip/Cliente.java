
/**
 * Esta clase hace referencia a los objetos Clientes.
 * 
 * @author Joaquin ferretto 
 *
 */
public class Cliente
{
    private int nroDNI;
    private String apellido;
    private String nombre;
    private double saldo;
    
    /**
     * Constructor de la clase cliente.
     * @param p_nroDNI,p_apellido,p_nombre,p_saldo.
     */
    public Cliente(int p_nroDNI,String p_apellido,String p_nombre,double p_saldo)
    {
        nroDNI=p_nroDNI;
        apellido=p_apellido;
        nombre=p_nombre;
        saldo=p_saldo;
    }

    /**
     * 
     */
    public void mostrar()
    {
        System.out.println("-Cliente-");
        System.out.println("Nombre y apellido :" + nomYape() + "(" + nroDNI + ")" );
        System.out.println("saldo: $" + saldo );
    }
    
    public double nuevoSaldo(double p_importe){
        return saldo;
    }
    
    public double agregarSaldo(double p_importe){
        saldo += p_importe;
        return saldo;
    }
    
    public String ApeYnom(){
        return apellido + " " + nombre ; 
    }
    
    public String nomYape(){
        return nombre + " " + apellido ; 
    }
}
