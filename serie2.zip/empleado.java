import java.util.*;
/**
 * Write a description of class empleado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class empleado
{
    private long cuil;
    private String apellido; 
    private String nombre;
    private double sueldoBasico;
    private int anioIngreso; 
    
    /**
     * Constructor for objects of class empleado
     */
    
    public empleado(long p_cuil, String p_apellido, String p_nombre,double p_sueldoBasico, int p_anioIngreso)
    {
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldoBasico(p_sueldoBasico);
        this.setAnioIngreso(p_anioIngreso);
     
    }

  
    public int antiguedad (int p_anioIngreso){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        
        return anioHoy - anioIngreso;
    }
    
    private void setCuil(long p_cuil){
        this.cuil=p_cuil;
    }
     private void setApellido(String p_apellido){
        this.apellido=p_apellido;
    }
     private void setNombre(String p_nombre){
        this.nombre= p_nombre;
    }
     private void setSueldoBasico(double p_sueldoBasico){
        this.sueldoBasico= p_sueldoBasico;
    }
     private void setAnioIngreso(int p_anioIngreso){
        this.anioIngreso = p_anioIngreso;
    }
    public long getCuil(){
        return cuil;
    }
     public String getApellido(){
         return apellido;
    }
     public String getNombre(){
         return nombre;
    }
     public double getSueldoBasico(){
         return sueldoBasico;
    }
     public int getAnioIngreso(){
         return anioIngreso;
    }
    
    private double descuento(){
        return ((sueldoBasico * 2) / 100 + 1500);
    }
    
    private double adicional(){
        if(antiguedad(anioIngreso) < 2){
            return ((sueldoBasico * 2) / 100); 
        }else if (antiguedad(anioIngreso) <= 2 && antiguedad(anioIngreso) < 10){
            return ((sueldoBasico * 4) / 100); 
        }else{
        return ((sueldoBasico * 6) / 100);
        }
    }
    
    public double sueldoNeto(){
        return (sueldoBasico + this.adicional()) - this.descuento();
    }
    
    public String apeYnom(){
        return this.getApellido() + "," + this.getNombre() ; 
    }
   
    public String nomYape(){
        return this.getNombre() + " " + this.getApellido() ; 
    }
    
    public void mostrar(){
        System.out.println("Nombre y Apellido: " + this.nomYape());
        System.out.println("CUIL: " + this.getCuil() + " " + "Antiguedad : " + this.antiguedad(anioIngreso) + " " + "años de servicio" );
        System.out.println("Sueldo Neto: $" + this.sueldoNeto());
    }
    public String mostrarLinea(){
        return (this.getCuil() + " " + this.apeYnom() + " " + "$"+ this.sueldoNeto());
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
